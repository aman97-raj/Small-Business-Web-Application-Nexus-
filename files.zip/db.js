// ─────────────────────────────────────────────────────────
//  NexaFlow — MySQL Database Connection
//  All credentials come from config.js — edit that file!
// ─────────────────────────────────────────────────────────

const mysql  = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const cfg    = require('../config');

// ── Create connection pool ────────────────────────────────
const pool = mysql.createPool({
  host:            cfg.DB_HOST,
  user:            cfg.DB_USER,
  password:        cfg.DB_PASSWORD,
  database:        cfg.DB_NAME,
  port:            cfg.DB_PORT,
  waitForConnections: true,
  connectionLimit:    10,
  charset:         'utf8mb4',
});

// ── Test connection on startup ────────────────────────────
async function testConnection() {
  try {
    const conn = await pool.getConnection();
    console.log(`✅  MySQL connected → ${cfg.DB_HOST} / ${cfg.DB_NAME}`);
    conn.release();
  } catch (err) {
    console.error('❌  MySQL connection FAILED:', err.message);
    console.error('   → Check your config.js DB_HOST, DB_USER, DB_PASSWORD, DB_NAME');
    process.exit(1);
  }
}

// ── Seed default data if tables are empty ────────────────
async function seed() {
  try {
    const [rows] = await pool.query('SELECT COUNT(*) AS cnt FROM users');
    if (rows[0].cnt > 0) return;

    console.log('🌱  Seeding database with demo data...');
    const adminHash = await bcrypt.hash('admin123', 10);
    const userHash  = await bcrypt.hash('user1234', 10);

    await pool.query(`
      INSERT INTO users (first_name, last_name, email, password, company, role, status, avatar, avatar_color, created_at)
      VALUES
        ('Super','Admin','admin@nexaflow.com',?,'NexaFlow Inc.','admin','active','SA','#e06c6c',DATE_SUB(NOW(),INTERVAL 120 DAY)),
        ('John','Doe','john@demo.com',?,'Demo Corp','user','active','JD','#c9a84c',DATE_SUB(NOW(),INTERVAL 90 DAY)),
        ('Sarah','Chen','sarah@acme.com',?,'Acme Ltd','manager','active','SC','#6ccea0',DATE_SUB(NOW(),INTERVAL 60 DAY)),
        ('Mike','Torres','mike@startup.io',?,'StartupIO','user','active','MT','#6ca8e0',DATE_SUB(NOW(),INTERVAL 45 DAY)),
        ('Elena','Russo','elena@design.eu',?,'DesignEU','user','inactive','ER','#a78bfa',DATE_SUB(NOW(),INTERVAL 30 DAY)),
        ('Omar','Hassan','omar@biznet.ae',?,'BizNet AE','user','banned','OH','#6b6870',DATE_SUB(NOW(),INTERVAL 20 DAY))
    `, [adminHash,userHash,userHash,userHash,userHash,userHash]);

    const [[john]] = await pool.query('SELECT id FROM users WHERE email = ?', ['john@demo.com']);
    await pool.query(`INSERT INTO tasks (user_id,text,priority,done) VALUES (?,?,?,?),(?,?,?,?),(?,?,?,?),(?,?,?,?),(?,?,?,?)`,
      [john.id,'Finalize Q3 financial report','high',1,
       john.id,'Review team performance metrics','medium',0,
       john.id,'Update onboarding documentation','low',0,
       john.id,'Schedule investor call for October','high',0,
       john.id,'Deploy v2.4.1 hotfix to production','high',1]);

    await pool.query(`INSERT INTO activities (type,icon,title,amount,amount_class) VALUES
      ('payment','💰','Payment received from Acme Corp','+$4,200','up'),
      ('user','👤','New user registered','+1','blue'),
      ('project','📦','Project Beta Launch updated','Active','gold'),
      ('alert','⚠️','Server usage spike detected','Alert','down'),
      ('complete','✅','Sprint #12 completed','Done','up')`);

    await pool.query(`INSERT INTO audit_logs (level,message) VALUES
      ('WARN','High memory usage threshold crossed on node-02'),
      ('INFO','User verified email address'),
      ('ERROR','Failed payment — card declined for sub #4412'),
      ('SUCCESS','Scheduled backup completed successfully'),
      ('INFO','Deploy v2.5.0 pushed to production')`);

    console.log('✅  Database seeded.');
  } catch (err) {
    console.error('⚠️  Seed error (import the SQL file first):', err.message);
  }
}

module.exports = { pool, testConnection, seed };
