// ╔══════════════════════════════════════════════════════╗
// ║         NexaFlow — DATABASE CONFIGURATION            ║
// ║  ✏️  ONLY EDIT THIS FILE with your InfinityFree      ║
// ║     MySQL details from your control panel            ║
// ╚══════════════════════════════════════════════════════╝

module.exports = {

  // ─────────────────────────────────────────────────────
  // 🔴  CHANGE THESE 4 VALUES  — get them from:
  //     InfinityFree Panel → MySQL Databases
  // ─────────────────────────────────────────────────────

  DB_HOST:     'sql209.infinityfree.com',   // ← Your MySQL Host (e.g. sql200.epizy.com)
  DB_USER:     'if0_xxxxxxxx',              // ← Your MySQL Username
  DB_PASSWORD: 'your_password_here',        // ← Your MySQL Password
  DB_NAME:     'if0_xxxxxxxx_nexaflow_db',  // ← Your Database Name

  // ─────────────────────────────────────────────────────
  // 🟡  OPTIONAL — change if needed
  // ─────────────────────────────────────────────────────

  DB_PORT: 3306,                            // MySQL port (always 3306)
  JWT_SECRET: 'nexaflow_super_secret_2025', // Change this to any long random string
  PORT: 3000,                               // Web server port

};

// ─────────────────────────────────────────────────────────
// 📌  WHERE TO FIND YOUR DETAILS ON INFINITYFREE:
//
//  1. Login → infinityfree.com/accounts
//  2. Click your hosting account
//  3. Go to "MySQL Databases" in control panel
//  4. You'll see:  MySQL Server, Database, Username, Password
//
//  Example values look like:
//    Host:     sql209.infinityfree.com
//    User:     if0_12345678
//    Password: (the one you set when creating DB)
//    Database: if0_12345678_nexaflow_db
// ─────────────────────────────────────────────────────────
